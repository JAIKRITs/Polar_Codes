The text folder contains text version of code file in Code folder. CodeFile are in python and matlab and text are those code copied in
text extension
