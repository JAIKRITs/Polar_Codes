Load file f_inverse_fun.mat first, than run script gaussian.m, f.m is a function file used in main script.

Variable f_inverse (that is stored in .mat file) can be generated through the script generateDict.m